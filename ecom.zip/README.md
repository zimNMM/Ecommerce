ecommerce app built on django 5.0.6
